const CONFIG = {
  BASE_URL: 'https://story-api.dicoding.dev/v1', 
  MAP_API_KEY: 'Du4PLKxSUoYiUTN8u8bl', 
};

export default CONFIG;
