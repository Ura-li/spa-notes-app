// src/utils/idb.js
// Simple wrapper import dari idb
import { openDB } from 'https://cdn.jsdelivr.net/npm/idb@7/+esm';

export { openDB };
